# -*- coding: utf-8 -*-
#
#################################################################################
# Author      : Weblytic Labs Pvt. Ltd. (<https://store.weblyticlabs.com/>)
# Copyright(c): 2023-Present Weblytic Labs Pvt. Ltd.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
##################################################################################

{
    'name': 'Prestashop Connector',
    'version': '18.0.1.0.0',
    'sequence': -1,
    'summary': """Prestashop Connector""",
    'description': """Prestashop Connector""",
    'category': 'eCommerce',
    'author': 'Weblytic Labs',
    'company': 'Weblytic Labs',
    'website': "https://store.weblyticlabs.com",
    'depends': ['base', 'web', 'website', 'website_sale', 'sale_management'],
    # 'images': ['static/description/banner.gif'],
    'license': 'OPL-1',
    'installable': True,
    'auto_install': False,
    'application': True,
    'data': [
        'security/ir.model.access.csv',
        'views/main_menubar.xml',
        'views/menubar_mapping.xml',
        'views/submenu_customer_group_view.xml',
        'views/submenu_customers_view.xml',
        'views/submenu_products_view.xml',
        'views/menubar_external.xml',
        'views/menubar_configuration.xml',
    ],
    'assets': {
        'point_of_sale._assets_pos': [
        ],
    }
}
