from odoo import models, fields

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    prestashop_order_line_id = fields.Integer(string="PrestaShop Order Line ID", index=True)
