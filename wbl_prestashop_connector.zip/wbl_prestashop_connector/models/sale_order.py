import requests
from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    student_name = fields.Char()
    prestashop_order_id = fields.Integer(string="Prestashop Sale Order ID", index=True)

    @api.model
    def sync_order_from_prestashop(self, base_url, api_key):
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        # Step 1: Fetch all order id of all orders

        base_url = base_url.rstrip('/')
        headers = {'Accept': 'application/json'}

        url = f"{base_url}/api/orders/?output_format=JSON"
        response = requests.get(url, headers=headers, auth=(api_key, ''))

        if response.status_code != 200:
            raise Exception(f"Failed to fetch product list: {response.text}")

        orders_data = response.json().get('orders', [])
        for order in orders_data:
            order_id = order['id']
            # Step 2: Full deatisl of perticual product
            order_url = f"{base_url}/api/orders/{order_id}/?output_format=JSON"
            order_response = requests.get(order_url, headers=headers, auth=(api_key, ''))

            full_order_data = order_response.json()['order']

            # Step 3: Check if order already exists
            existing_order = self.search([('prestashop_order_id', '=', order_id)], limit=1)

            # Step 4: Prepare common values
            prestashop_customer_id = int(full_order_data['id_customer'])

            # Search in res.partner by prestashop_customer_id
            partner = self.env['res.partner'].search([
                ('prestashop_customer_id', '=', prestashop_customer_id)
            ], limit=1)

            if not partner:
                # Create partner placeholder if not found
                partner = self.env['res.partner'].create({
                    'name': f"Customer {prestashop_customer_id}",
                    'prestashop_customer_id': prestashop_customer_id,
                })

            # Ye Logice tb used hoga(Jb Addressh diff. honge smje.)
            invoice_address_id_ps = int(full_order_data.get('id_address_invoice', 0))
            delivery_address_id_ps = int(full_order_data.get('id_address_delivery', 0))

            # fetCh inVoice AddrSh
            invoice_partner = self.env['res.partner'].search([
                ('prestashop_address_id', '=', invoice_address_id_ps),
                ('parent_id', '=', partner.id)
            ], limit=1)

            # fetCh Delivery AddrSh
            shipping_partner = self.env['res.partner'].search([
                ('prestashop_address_id', '=', delivery_address_id_ps),
                ('parent_id', '=', partner.id)
            ], limit=1)

            vals = {
                'partner_id': partner.id,
                'partner_invoice_id': invoice_partner.id or partner.id,
                'partner_shipping_id': shipping_partner.id or partner.id,
                'prestashop_order_id': order_id,
                'name': f"PS-{order_id}",
            }

            if existing_order:
                existing_order.write(vals)
                order_record = existing_order
            else:
                order_record = self.create(vals)

            # Step 5: Order Lines
            OrderLine = self.env['sale.order.line']
            order_lines = full_order_data.get('associations', {}).get('order_rows', [])
            if isinstance(order_lines, dict):  # in case only one line exists
                order_lines = [order_lines]

            for line in order_lines:
                line_id = int(line['id'])
                product_name = line.get('product_name', 'Product')
                quantity = float(line.get('product_quantity', 0))
                price = float(line.get('unit_price_tax_incl', 0.0))

                #  Get PrestaShop product & combination ID
                product_id_ps = int(line.get('product_id', 0))
                combination_id_ps = int(line.get('product_attribute_id', 0))

                #  Find product in Odoo
                product = None
                template = self.env['product.template'].search([
                    ('prestashop_product_id', '=', product_id_ps)
                ], limit=1)

                if combination_id_ps and template:
                    product = self.env['product.product'].search([
                        ('prestashop_combination_id', '=', combination_id_ps),
                        ('product_tmpl_id', '=', template.id)
                    ], limit=1)
                elif template:
                    product = template.product_variant_id

                existing_line = OrderLine.search([
                    ('order_id', '=', order_record.id),
                    ('prestashop_order_line_id', '=', line_id)
                ], limit=1)

                line_vals = {
                    'order_id': order_record.id,
                    'name': product_name,
                    'product_uom_qty': quantity,
                    'price_unit': price,
                    'prestashop_order_line_id': line_id,
                    'product_id': product.id if product else False,
                }

                if existing_line:
                    existing_line.write(line_vals)
                else:
                    OrderLine.create(line_vals)
