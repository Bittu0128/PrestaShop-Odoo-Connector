from odoo import models, fields

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    student_name = fields.Char()