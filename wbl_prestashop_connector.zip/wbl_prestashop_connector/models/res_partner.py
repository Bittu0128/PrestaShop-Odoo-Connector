import requests
import logging
from odoo import models, fields, api

_logger = logging.getLogger(__name__)


class ResPartner(models.Model):
    _inherit = 'res.partner'

    customer_groups = fields.Many2one('customer.groups', 'Customer Groups')
    prestashop_customer_id = fields.Integer(string="PrestaShop Customer Id", index=True)    #===>> Store Customer ID
    prestashop_address_id = fields.Integer(string="PrestaShop Address Id", index=True)      #===>> Store Address ID
    prestashop_supplier_id = fields.Integer(string="PrestaShop Supplier Id")                #===>> Store Suppliers ID

    # This Mani Fun. JO First me Call hota ha. (Just Like Controller)
    @api.model
    def sync_customers_from_prestashop(self, base_url=None, api_key=None):
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        base_url = base_url.rstrip('/') + "/api"
        headers = {'Accept': 'application/json'}

        list_url = f"{base_url}/customers/?output_format=JSON"
        response = requests.get(list_url, headers=headers, auth=(api_key, ''))
        if response.status_code != 200:
            raise Exception(f"Failed to fetch customer list: {response.text}")

        customer_ids = response.json().get("customers", [])

        for cust in customer_ids:
            cust_id = cust.get("id")
            customer = self._get_prestashop_customer(base_url, api_key, cust_id)
            if not customer:
                continue

            # 💡 Step 1: Check for company
            company_name = customer.get("company")
            company_partner = None
            if company_name:
                company_vals = {
                    'name': company_name,
                    'is_company': True,
                    'company_type': 'company',
                }
                company_partner = self._create_or_update_partner(company_vals, is_address=False)

            # 💡 Step 2: Create/update customer under company (if exists)
            parent_vals = self._prepare_customer_vals(customer, parent=company_partner)
            parent_partner = self._create_or_update_partner(parent_vals, is_address=False)

            # Skip if parent couldn't be created
            if not parent_partner:
                continue

            # 💡 Step 3: Sync addresses
            addresses = self._get_all_addresses(base_url, api_key, cust_id)
            for address in addresses:
                addr_vals = self._prepare_address_vals(customer, address, base_url, api_key, parent=parent_partner)
                if addr_vals:
                    self._create_or_update_partner(addr_vals, is_address=True)

    # HEALPER FUNCTION =====> sync customer
    def _get_prestashop_customer(self, base_url, api_key, customer_id):
        url = f"{base_url}/customers/{customer_id}/?output_format=JSON"
        response = requests.get(url, auth=(api_key, ''), headers={'Accept': 'application/json'})
        if response.status_code == 200:
            return response.json().get("customer", {})
        return None

    # HEALPER FUNCTION =====> sync Country for Addresh
    def _get_country_from_prestashop(self, base_url, api_key, ps_country_id):
        url = f"{base_url}/countries/{ps_country_id}/?output_format=JSON"
        response = requests.get(url, auth=(api_key, ''), headers={'Accept': 'application/json'})
        if response.status_code == 200:
            country_data = response.json().get("country", {})
            if country_data and country_data.get("name"):
                country_name = country_data["name"][0]["value"]
                return self.env['res.country'].search([('name', '=', country_name)], limit=1)
        return None

    # HEALPER FUNCTION =====> sync State for Addresh + Countery
    def _get_state_from_prestashop(self, base_url, api_key, ps_state_id, country=None):
        url = f"{base_url}/states/{ps_state_id}/?output_format=JSON"
        response = requests.get(url, auth=(api_key, ''), headers={'Accept': 'application/json'})
        if response.status_code == 200:
            state_data = response.json().get("state", {})
            if state_data:
                state_name = state_data.get("name")
                domain = [('name', '=', state_name)]
                if country:
                    domain.append(('country_id', '=', country.id))
                return self.env['res.country.state'].search(domain, limit=1)
        return None

    # Ye Customer ko create krta ha.
    def _prepare_customer_vals(self, customer, parent=None):
        name = f"{customer.get('firstname')} {customer.get('lastname')}".strip()
        group_id = int(customer.get("id_default_group"))
        group = self.env['customer.groups'].search([('prestashop_group_id', '=', group_id)], limit=1)

        vals = {
            'prestashop_customer_id': int(customer.get("id")),
            'name': name,
            'email': customer.get("email"),
            'active': customer.get("active") == "1",
            'customer_groups': group.id if group else False,
            'is_company': False,
            'company_type': 'person',
        }

        if parent:
            vals['parent_id'] = parent.id

        return vals

    # Ye Addresh and Company ko Create KRTA HA.
    def _prepare_address_vals(self, customer, address, base_url, api_key, parent=False):
        if not parent:
            return None

        country = self._get_country_from_prestashop(base_url, api_key, address.get("id_country")) if address.get(
            "id_country") else None
        state = self._get_state_from_prestashop(base_url, api_key, address.get("id_state"), country) if address.get(
            "id_state") else None

        street = f"{address.get('address1', '')} {address.get('address2', '')}".strip()
        address_name = address.get('alias') or 'Address'

        # Detect type based on alias
        alias_lower = (address.get('alias') or '').lower()
        addr_type = 'other'
        if 'invoice' in alias_lower:
            addr_type = 'invoice'
        elif 'delivery' in alias_lower or 'shipping' in alias_lower:
            addr_type = 'delivery'

        vals = {
            'name': address_name,
            'street': street,
            'city': address.get("city"),
            'zip': address.get("postcode"),
            'phone': address.get("phone") or address.get("phone_mobile"),
            'mobile': address.get("phone_mobile") or address.get("phone"),
            'country_id': country.id if country else False,
            'state_id': state.id if state else False,
            'type': addr_type,
            'parent_id': parent.id,
            'is_company': False,
            'company_type': 'person',
            'prestashop_address_id': int(address.get("id")),
        }
        return vals

    # Ye Ensure krta ka koi Recorde Duble na bane (Update and Create this)
    def _create_or_update_partner(self, vals, is_address=False):
        if is_address:
            # Match by PrestaShop Address ID
            domain = [('prestashop_address_id', '=', vals.get('prestashop_address_id'))]
        elif vals.get('is_company'):
            # Match company partner by name and is_company
            domain = [('name', '=', vals.get('name')), ('is_company', '=', True)]
        else:
            # Match by email or PrestaShop Customer ID
            domain = ['|',
                      ('email', '=', vals.get('email')),
                      ('prestashop_customer_id', '=', vals.get('prestashop_customer_id'))]

        existing = self.search(domain, limit=1)
        if existing:
            existing.write(vals)
            return existing
        else:
            return self.create(vals)

    # Handel Muliple Add of a Single cUTOMER
    def _get_all_addresses(self, base_url, api_key, customer_id):
        addr_url = f"{base_url}/addresses/?filter[id_customer]={customer_id}&output_format=JSON"
        response = requests.get(addr_url, headers={'Accept': 'application/json'}, auth=(api_key, ''))

        if response.status_code != 200:
            print(f"❌ Failed to fetch address list for customer {customer_id}. Status: {response.status_code}")
            return []

        try:
            address_ids = response.json().get("addresses", [])
        except Exception as e:
            print(f"❌ JSON decode error for customer {customer_id}: {e}")
            return []

        addresses = []
        for addr in address_ids:
            addr_id = addr.get("id")
            if not addr_id:
                continue

            detail_url = f"{base_url}/addresses/{addr_id}/?output_format=JSON"
            detail_resp = requests.get(detail_url, headers={'Accept': 'application/json'}, auth=(api_key, ''))

            if detail_resp.status_code != 200:
                print(f"❌ Failed to fetch address {addr_id}. Status: {detail_resp.status_code}")
                continue

            try:
                addr_data = detail_resp.json().get("address", {})
                if addr_data:
                    addresses.append(addr_data)
            except Exception as e:
                print(f"  Failed to decode address {addr_id}: {e}")
                continue

        return addresses

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<================= Import Supplier Data =================================>>>>>>>>>>>>

    @api.model
    def sync_suppliers_from_prestashop(self, base_url=None, api_key=None):
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        base_url = base_url.rstrip('/') + "/api"
        headers = {'Accept': 'application/json'}

        list_url = f"{base_url}/suppliers/?output_format=JSON"
        response = requests.get(list_url, headers=headers, auth=(api_key, ''))

        if response.status_code != 200:
            _logger.error(f"❌ Failed to fetch supplier list: {response.text}")
            return

        supplier_ids = response.json().get("suppliers", [])
        for supp in supplier_ids:
            supp_id = supp.get("id")
            supplier = self._get_prestashop_supplier(base_url, api_key, supp_id)
            if not supplier:
                continue

            # Step 1: Create/update main supplier company
            supplier_vals = self._prepare_supplier_vals(supplier)
            supplier_partner = self._create_or_update_partner(supplier_vals, is_address=False)

            if not supplier_partner:
                continue

            # Step 2: Fetch and link supplier address
            address = self._get_supplier_address(base_url, api_key, supp_id)
            if address:
                addr_vals = self._prepare_supplier_address_vals(address, base_url, api_key, parent=supplier_partner)
                if addr_vals:
                    self._create_or_update_partner(addr_vals, is_address=True)

    def _get_prestashop_supplier(self, base_url, api_key, supplier_id):
        url = f"{base_url}/suppliers/{supplier_id}/?output_format=JSON"
        response = requests.get(url, auth=(api_key, ''), headers={'Accept': 'application/json'})
        if response.status_code == 200:
            return response.json().get("supplier", {})
        return None

    def _get_supplier_address(self, base_url, api_key, supplier_id):
        addr_url = f"{base_url}/addresses/?filter[id_supplier]={supplier_id}&output_format=JSON"
        response = requests.get(addr_url, auth=(api_key, ''), headers={'Accept': 'application/json'})

        if response.status_code != 200:
            return None

        # ✅ Defensive: Make sure JSON is a dict
        try:
            res_json = response.json()
        except Exception as e:
            _logger.error(f" JSON decode failed for supplier {supplier_id}: {e}")
            return None

        if not isinstance(res_json, dict):
            _logger.error(f" Expected dict but got {type(res_json)} for supplier {supplier_id}")
            return None

        addresses = res_json.get("addresses", [])
        if not addresses or not isinstance(addresses[0], dict):
            return None

        addr_id = addresses[0].get("id")
        if not addr_id:
            return None

        detail_url = f"{base_url}/addresses/{addr_id}/?output_format=JSON"
        detail_resp = requests.get(detail_url, auth=(api_key, ''), headers={'Accept': 'application/json'})
        if detail_resp.status_code != 200:
            return None

        return detail_resp.json().get("address", {})

    def _prepare_supplier_vals(self, supplier):
        return {
            'name': supplier.get("name", "").strip(),
            'is_company': True,
            'company_type': 'company',
            'active': supplier.get("active") == "1",
            'prestashop_supplier_id': int(supplier.get("id")),
        }

    def _prepare_supplier_address_vals(self, address, base_url, api_key, parent=False):
        if not parent:
            return None

        country = self._get_country_from_prestashop(base_url, api_key, address.get("id_country")) if address.get(
            "id_country") else None
        state = self._get_state_from_prestashop(base_url, api_key, address.get("id_state"), country) if address.get(
            "id_state") else None

        street = f"{address.get('address1', '')}".strip()
        city = address.get('city')
        zip_code = address.get('postcode')
        phone = address.get('phone')
        name = address.get('alias') or 'Supplier Address'

        vals = {
            'name': name,
            'street': street,
            'city': city,
            'zip': zip_code,
            'phone': phone,
            'country_id': country.id if country else False,
            'state_id': state.id if state else False,
            # 'type': 'other',
            'parent_id': parent.id,
            'is_company': False,
            'company_type': 'person',
            'prestashop_address_id': int(address.get("id")),
        }
        return vals

    def _create_or_update_partner(self, vals, is_address=False):
        if is_address:
            domain = [('prestashop_address_id', '=', vals.get('prestashop_address_id'))]
        elif vals.get('is_company') and vals.get('prestashop_supplier_id'):
            domain = [('prestashop_supplier_id', '=', vals.get('prestashop_supplier_id'))]
        else:
            domain = [('name', '=', vals.get('name'))]

        existing = self.search(domain, limit=1)
        if existing:
            existing.write(vals)
            return existing
        else:
            return self.create(vals)
