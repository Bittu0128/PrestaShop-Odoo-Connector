import requests
from odoo import models, fields, api


class ResPartner(models.Model):
    _inherit = 'res.partner'

    customer_groups = fields.Many2one('customer.groups')
    prestashop_customer_id = fields.Integer(string="PrestaShop Customer Id")

    @api.model
    def sync_customers_from_prestashop(self, base_url=None, api_key=None):
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        base_url = base_url.rstrip('/') + "/api"
        headers = {'Accept': 'application/json'}

        list_url = f"{base_url}/customers/?output_format=JSON"
        response = requests.get(list_url, headers=headers, auth=(api_key, ''))
        if response.status_code != 200:
            raise Exception(f"Failed to fetch customer list: {response.text}")

        customer_ids = response.json().get("customers", [])

        for cust in customer_ids:
            cust_id = cust.get("id")
            customer = self._get_prestashop_customer(base_url, api_key, cust_id)
            if not customer:
                continue

            address = self._get_prestashop_customer_address(base_url, api_key, cust_id)
            vals = self._prepare_customer_vals(customer, address, base_url, api_key)

            self._create_or_update_partner(vals)

    def _get_prestashop_customer(self, base_url, api_key, customer_id):
        url = f"{base_url}/customers/{customer_id}/?output_format=JSON"
        response = requests.get(url, auth=(api_key, ''), headers={'Accept': 'application/json'})
        if response.status_code == 200:
            return response.json().get("customer", {})
        return None

    def _get_prestashop_customer_address(self, base_url, api_key, customer_id):
        addr_url = f"{base_url}/addresses/?filter[id_customer]={customer_id}&output_format=JSON"
        response = requests.get(addr_url, headers={'Accept': 'application/json'}, auth=(api_key, ''))
        addr_data = response.json()

        if isinstance(addr_data, dict):
            addr_list = addr_data.get("addresses", [])
            if addr_list:
                addr_id = addr_list[0].get("id")
                detail_url = f"{base_url}/addresses/{addr_id}/?output_format=JSON"
                detail_resp = requests.get(detail_url, headers={'Accept': 'application/json'}, auth=(api_key, ''))
                if detail_resp.status_code == 200:
                    return detail_resp.json().get("address", {})
        return {}

    def _get_country_from_prestashop(self, base_url, api_key, ps_country_id):
        url = f"{base_url}/countries/{ps_country_id}/?output_format=JSON"
        response = requests.get(url, auth=(api_key, ''), headers={'Accept': 'application/json'})
        if response.status_code == 200:
            country_data = response.json().get("country", {})
            if country_data and country_data.get("name"):
                country_name = country_data["name"][0]["value"]
                return self.env['res.country'].search([('name', '=', country_name)], limit=1)
        return None

    def _get_state_from_prestashop(self, base_url, api_key, ps_state_id, country=None):
        url = f"{base_url}/states/{ps_state_id}/?output_format=JSON"
        response = requests.get(url, auth=(api_key, ''), headers={'Accept': 'application/json'})
        if response.status_code == 200:
            state_data = response.json().get("state", {})
            if state_data:
                state_name = state_data.get("name")
                domain = [('name', '=', state_name)]
                if country:
                    domain.append(('country_id', '=', country.id))
                return self.env['res.country.state'].search(domain, limit=1)
        return None

    def _prepare_customer_vals(self, customer, address, base_url, api_key):
        name = f"{customer.get('firstname')} {customer.get('lastname')}".strip()
        group_id = int(customer.get("id_default_group"))
        group = self.env['customer.groups'].search([('prestashop_group_id', '=', group_id)], limit=1)

        country = self._get_country_from_prestashop(base_url, api_key, address.get("id_country")) if address else None
        state = self._get_state_from_prestashop(base_url, api_key, address.get("id_state"),
                                                country) if address else None

        address_data = {
            'street': f"{address.get('address1', '')} {address.get('address2', '')}".strip(),
            'city': address.get("city"),
            'zip': address.get("postcode"),
            'phone': address.get("phone"),
            'mobile': address.get("phone_mobile"),
            'country_id': country.id if country else False,
            'state_id': state.id if state else False,
        } if address else {}

        # Handle company idea
        company_name = customer.get("company")
        parent_id = False
        is_company = False

        if company_name:
            company = self.env['res.partner'].search([('name', '=', company_name), ('is_company', '=', True)], limit=1)
            if not company:
                company = self.env['res.partner'].create({
                    'name': company_name,
                    'is_company': True,
                    'company_type': 'company',
                })
            parent_id = company.id
            is_company = False  # Customer is individual under company

        vals = {
            'prestashop_customer_id': int(customer.get("id")),
            'name': name,
            'complete_name': name,
            'email': customer.get("email"),
            'active': customer.get("active") == "1",
            'customer_groups': group.id if group else False,
            'website': customer.get("website"),
            'is_company': is_company,
            'company_type': 'person',
            'parent_id': parent_id,
            **address_data,
        }

        return vals

    def _create_or_update_partner(self, vals):
        domain = ['|', ('email', '=', vals.get('email')),
                  ('prestashop_customer_id', '=', vals.get('prestashop_customer_id'))]
        existing = self.search(domain, limit=1)
        if existing:
            existing.write(vals)
        else:
            self.create(vals)
