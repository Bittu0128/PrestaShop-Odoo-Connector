from . import prestashop_connector
from . import customer_groups
from . import res_partner
from . import sale_order
from . import sale_order_line
from . import product_product
from . import product_template
from . import product_attribute
from . import product_attribute_value
from . import product_combo
from . import product_combo_item
from . import product_public_category
# from . import stock_quant
