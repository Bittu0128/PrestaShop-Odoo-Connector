import requests
from odoo import models, fields, api


class ProductAttribute(models.Model):
    _inherit = 'product.attribute'

    prestashop_attribute_id = fields.Integer(string="PrestaShop Attribute ID", index=True)

    @api.model
    def sync_attribute_from_prestashop(self, base_url=None, api_key=None):
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        base_url = base_url.rstrip('/') + "/api"
        headers = {'Accept': 'application/json'}

        list_url = f"{base_url}/product_options/?output_format=JSON"
        response = requests.get(list_url, headers=headers, auth=(api_key, ''))

        if response.status_code != 200:
            raise Exception(f"Failed to fetch attribute list: {response.text}")

        product_attribute_list = response.json().get("product_options", [])

        for attr in product_attribute_list:
            attr_id = attr.get("id")
            attr_data = self._get_prestashop_attribute(base_url, api_key, attr_id)
            if not attr_data:
                continue

            vals = self._prepare_attribute_vals(attr_data)
            self._create_or_update_attribute(vals)

    def _get_prestashop_attribute(self, base_url, api_key, attr_id):
        url = f"{base_url}/product_options/{attr_id}/?output_format=JSON"
        response = requests.get(url, headers={'Accept': 'application/json'}, auth=(api_key, ''))
        if response.status_code == 200:
            return response.json().get("product_option", {})
        return None

    def _prepare_attribute_vals(self, data):
        name_list = data.get("name", [])
        public_name_list = data.get("public_name", [])

        # English language preference or first fallback
        def _get_lang_value(lst, lang_id='1'):  # Assuming ID 1 is English
            for item in lst:
                if item.get("id") == lang_id:
                    return item.get("value")
            return lst[0].get("value") if lst else "Unnamed"

        name = _get_lang_value(name_list)
        public_name = _get_lang_value(public_name_list)

        return {
            'name': name or public_name,
            'prestashop_attribute_id': int(data.get("id")),
        }

    def _create_or_update_attribute(self, vals):
        domain = [('prestashop_attribute_id', '=', vals.get('prestashop_attribute_id'))]
        existing = self.search(domain, limit=1)
        if existing:
            existing.write(vals)
        else:
            self.create(vals)
