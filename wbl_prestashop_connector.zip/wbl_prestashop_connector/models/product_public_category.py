import requests
from odoo import models, fields, api
import logging

_logger = logging.getLogger(__name__)


class ProductPublicCategory(models.Model):
    _inherit = 'product.public.category'

    prestashop_category_id = fields.Integer(string="PrestaShop Category ID")

    @api.model
    def sync_categories_from_prestashop(self, base_url=None, api_key=None):
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        base_url = base_url.rstrip('/') + "/api"
        headers = {'Accept': 'application/json'}

        # Step 1: Fetch all category IDs
        list_url = f"{base_url}/categories/?output_format=JSON"
        response = requests.get(list_url, headers=headers, auth=(api_key, ''))
        if response.status_code != 200:
            raise Exception(f"Failed to fetch category list: {response.text}")

        category_ids = [int(cat['id']) for cat in response.json().get("categories", [])]

        # Step 2: Sync each category (with parent recursion)
        mapped_ids = {}
        for presta_id in category_ids:
            try:
                self._sync_single_category(presta_id, base_url, api_key, mapped_ids)
            except Exception as e:
                _logger.warning(f"Category ID {presta_id} sync failed: {e}")

    def _sync_single_category(self, presta_id, base_url, api_key, mapped_ids):
        if presta_id in mapped_ids:
            return mapped_ids[presta_id]

        url = f"{base_url}/categories/{presta_id}/?output_format=JSON"
        response = requests.get(url, headers={'Accept': 'application/json'}, auth=(api_key, ''))
        if response.status_code != 200:
            return None

        data = response.json().get("category", {})

        name_list = data.get("name", [])
        name = next((n['value'] for n in name_list if n['id'] == '1'),
                    name_list[0]['value'] if name_list else 'Unnamed')

        parent_id = int(data.get("id_parent", 0))
        odoo_parent_id = None
        if parent_id not in [0, 1]:  # root id=1 usually
            odoo_parent_id = self._sync_single_category(parent_id, base_url, api_key, mapped_ids)

        vals = {
            'name': name,
            'prestashop_category_id': presta_id,
            'parent_id': odoo_parent_id
        }

        domain = [('prestashop_category_id', '=', presta_id)]
        existing = self.search(domain, limit=1)
        if existing:
            existing.write(vals)
            category = existing
        else:
            category = self.create(vals)

        mapped_ids[presta_id] = category.id
        return category.id
