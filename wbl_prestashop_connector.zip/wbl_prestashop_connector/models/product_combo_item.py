from odoo import api, models


class ProductComboItem(models.Model):
    _inherit = 'product.combo.item'