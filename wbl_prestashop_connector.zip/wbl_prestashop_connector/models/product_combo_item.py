from odoo import api, models, fields


class ProductComboItem(models.Model):
    _inherit = 'product.combo.item'

    presta_combo_item_id = fields.Integer(string="PrestaShop Combo Item ID")
