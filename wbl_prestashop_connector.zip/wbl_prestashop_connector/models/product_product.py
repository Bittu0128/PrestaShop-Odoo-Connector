from odoo import models, fields

class ProductProduct(models.Model):
    _inherit = 'product.product'

    prestashop_product_id = fields.Integer(related='product_tmpl_id.prestashop_product_id', store=True, readonly=False)

    prestashop_combination_id = fields.Integer(string="PrestaShop Combination ID")

