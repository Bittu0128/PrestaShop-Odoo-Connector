from odoo import models, fields, api
import requests
import logging

_logger = logging.getLogger(__name__)

class ProductProduct(models.Model):
    _inherit = 'product.product'

    prestashop_product_id = fields.Integer(related='product_tmpl_id.prestashop_product_id', store=True, readonly=False)

    prestashop_combination_id = fields.Integer(string="PrestaShop Combination ID") # just for my logic
    stock_availables_id = fields.Integer(string="PrestaShop Combination ID") # just for my logic

    @api.model
    def update_stock_available_id(self, product_data):
        """
        Set stock_availables_id and prestashop_combination_id for:
        - Standard products (id_product_attribute = 0)
        - Combination products (id_product_attribute != 0)
        """
        product_type = product_data.get("product_type")
        prestashop_product_id = int(product_data.get("id"))
        stock_availables = product_data.get("associations", {}).get("stock_availables", [])

        for stock in stock_availables:
            stock_available_id = int(stock.get("id"))
            id_attr = stock.get("id_product_attribute")

            if product_type == "standard" and id_attr == "0":
                # ✅ Standard product: set stock ID
                product = self.search([
                    ('prestashop_product_id', '=', prestashop_product_id),
                    ('prestashop_combination_id', '=', False)
                ], limit=1)
                if product:
                    product.stock_availables_id = stock_available_id

            elif product_type == "combinations":
                if id_attr == "0":
                    # ❌ Skip invalid entry for combinations
                    continue

                combination_id = int(id_attr)

                # 🔍 Find unlinked variant to update
                variant = self.search([
                    ('prestashop_product_id', '=', prestashop_product_id),
                    ('prestashop_combination_id', '=', False)
                ], limit=1)

                if variant:
                    variant.write({
                        'prestashop_combination_id': combination_id,
                        'stock_availables_id': stock_available_id
                    })

