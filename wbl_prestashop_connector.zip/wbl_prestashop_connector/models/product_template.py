import requests
from odoo import models, fields, api


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    prestashop_product_id = fields.Integer(string="PrestaShop Product ID")

    def sync_products_from_prestashop(self, base_url=None, api_key=None):
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        base_url = base_url.rstrip('/') + "/api"
        headers = {'Accept': 'application/json'}

        list_url = f"{base_url}/products/?output_format=JSON"
        response = requests.get(list_url, headers=headers, auth=(api_key, ''))

        if response.status_code != 200:
            raise Exception(f"Failed to fetch product list: {response.text}")

        product_list = response.json().get("products", [])
        for prod in product_list:
            product_id = prod.get("id")
            product_data = self._get_prestashop_product(base_url, api_key, product_id)
            if not product_data:
                continue

            vals = self._prepare_product_vals(product_data)
            self._create_or_update_product(vals)

    def _get_prestashop_product(self, base_url, api_key, product_id):
        url = f"{base_url}/products/{product_id}/?output_format=JSON"
        response = requests.get(url, headers={'Accept': 'application/json'}, auth=(api_key, ''))
        if response.status_code == 200:
            return response.json().get("product", {})
        return None

    def _prepare_product_vals(self, product):
        name = product.get("name", [{}])[0].get("value", "")
        price = float(product.get("price", 0.0))
        reference = product.get('reference')
        height = float(product.get("height", 0.0)) / 100
        depth = float(product.get("depth", 0.0)) / 100
        width = float(product.get("width", 0.0)) / 100
        weight = product.get("weight")
        volume = float(height * depth * width)
        description = product.get("description", [{}])[0].get("value", "")
        product_type = product.get("product_type")

        if product_type in ["standard", "combination"]:
            odoo_type = "consu"
        elif product_type == "virtual":
            odoo_type = "service"
        elif product_type == "pack":
            odoo_type = "combo"
        else:
            odoo_type = "consu"

        return {
            'prestashop_product_id': int(product.get("id")),
            'name': name,
            'list_price': price,  # ✅ Correct field name is list_price in product.template
            'default_code': reference,
            'weight': weight,
            'volume': volume,
            'description': description,
            'type': odoo_type,
        }

    def _create_or_update_product(self, vals):
        domain = [('prestashop_product_id', '=', vals.get('prestashop_product_id'))]
        existing = self.search(domain, limit=1)
        if existing:
            existing.write(vals)
        else:
            self.create(vals)
