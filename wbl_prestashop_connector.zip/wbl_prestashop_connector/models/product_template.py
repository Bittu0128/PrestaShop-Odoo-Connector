import requests
from odoo import models, fields, api
import logging

_logger = logging.getLogger(__name__)


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    prestashop_product_id = fields.Integer(string="PrestaShop Product ID", index=True)

    def sync_products_from_prestashop(self, base_url=None, api_key=None):
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        base_url = base_url.rstrip('/') + "/api"
        headers = {'Accept': 'application/json'}

        list_url = f"{base_url}/products/?output_format=JSON"
        response = requests.get(list_url, headers=headers, auth=(api_key, ''))

        if response.status_code != 200:
            raise Exception(f"Failed to fetch product list: {response.text}")

        product_list = response.json().get("products", [])
        if not product_list:
            print("No products found from PrestaShop.")
            return

        for prod in product_list:
            product_id = prod.get("id")
            product_data = self._get_prestashop_product(base_url, api_key, product_id)
            if not product_data:
                continue

            if product_data.get("product_type") != "pack":
                vals = self._prepare_product_vals(product_data)
                self._create_or_update_product(vals, product_data)

                # At the end of sync_products_from_prestashop

        for prod in product_list:
            product_id = prod.get("id")
            product_data = self._get_prestashop_product(base_url, api_key, product_id)
            if not product_data:
                continue

            if product_data.get("product_type") == "pack":
                vals = self._prepare_product_vals(product_data)
                product_bundle = product_data.get("associations", {}).get("product_bundle", [])
                self._create_combo_product(vals, product_bundle)

        self.env['product.template'].sync_prestashop_product_stock(base_url, api_key)

    def _get_prestashop_product(self, base_url, api_key, product_id):
        url = f"{base_url}/products/{product_id}/?output_format=JSON"
        response = requests.get(url, headers={'Accept': 'application/json'}, auth=(api_key, ''))
        if response.status_code == 200:
            return response.json().get("product", {})
        return None

    def _prepare_product_vals(self, product):
        name = product.get("name", [{}])[0].get("value", "")
        price = float(product.get("price", 0.0))
        reference = product.get('reference')
        height = float(product.get("height", 0.0)) / 100
        depth = float(product.get("depth", 0.0)) / 100
        width = float(product.get("width", 0.0)) / 100
        weight = product.get("weight")
        volume = float(height * depth * width)
        description = product.get("description", [{}])[0].get("value", "")
        product_type = product.get("product_type")
        cost_price = product.get('wholesale_price')

        if product_type in ["standard", "combinations"]:
            odoo_type = "consu"
            is_storable = True
        elif product_type == "virtual":
            odoo_type = "service"
            is_storable = False
        elif product_type == "pack":
            odoo_type = "combo"
            is_storable = False
        else:
            odoo_type = "consu"
            is_storable = False

        return {
            'prestashop_product_id': int(product.get("id")),
            'name': name,
            'list_price': price,
            'default_code': reference,
            'weight': weight,
            'volume': volume,
            'description': description,
            'type': odoo_type,
            'standard_price': cost_price,
            'is_storable': is_storable,
        }

    def _sync_attribute_lines_from_presta(self, template, product_data):
        option_values = product_data.get('associations', {}).get('product_option_values', [])
        if not option_values:
            return

        presta_val_ids = [int(val['id']) for val in option_values]

        odoo_values = self.env['product.attribute.value'].search([
            ('prestashop_attr_value_id', 'in', presta_val_ids)
        ])

        grouped = {}
        for val in odoo_values:
            attr_id = val.attribute_id.id
            grouped.setdefault(attr_id, []).append(val.id)

        for attr_id, val_ids in grouped.items():
            line = self.env['product.template.attribute.line'].search([
                ('product_tmpl_id', '=', template.id),
                ('attribute_id', '=', attr_id)
            ], limit=1)

            if line:
                existing_vals = set(line.value_ids.ids)
                new_vals = set(val_ids)
                line.value_ids = [(6, 0, list(existing_vals.union(new_vals)))]
            else:
                self.env['product.template.attribute.line'].create({
                    'product_tmpl_id': template.id,
                    'attribute_id': attr_id,
                    'value_ids': [(6, 0, val_ids)]
                })

    # This Fun. for Product Categorys(Mtlv Sales Categorys)
    def _assign_categories_from_presta(self, product_data, template):
        category_ids = set()
        default_cat = product_data.get("id_category_default")
        if default_cat:
            category_ids.add(int(default_cat))
        associations = product_data.get("associations", {})
        for cat in associations.get("categories", []):
            category_ids.add(int(cat['id']))

        if not category_ids:
            return

        odoo_cats = self.env['product.public.category'].search([
            ('prestashop_category_id', 'in', list(category_ids))
        ])

        if odoo_cats:
            template.public_categ_ids = [(6, 0, odoo_cats.ids)]

    def _create_combo_product(self, vals, product_bundle):
        product_name = vals.get('name') or 'Combo Choise'
        prestashop_product_id = vals.get('prestashop_product_id')

        ProductTemplate = self.env['product.template']
        ProductCombo = self.env['product.combo']
        ProductComboItem = self.env['product.combo.item']

        # 🔍 Check for existing combo template
        existing_template = ProductTemplate.search([
            ('prestashop_product_id', '=', prestashop_product_id),
            ('type', '=', 'combo'),
        ], limit=1)

        combo_choise = None

        if existing_template:
            _logger.info(
                f"🔁 Combo product already exists for PrestaShop ID {prestashop_product_id}, updating combo choise.")

            # Try to find linked combo
            combo_choise = existing_template.combo_ids.filtered(
                lambda c: c.presta_combo_id == prestashop_product_id
            )
            if combo_choise:
                combo_choise.write({'name': product_name})
            else:
                combo_choise = ProductCombo.create({
                    'name': product_name,
                    'presta_combo_id': prestashop_product_id,
                })
                existing_template.combo_ids = [(4, combo_choise.id)]  # Add M2M without overwriting
        else:
            # Combo product doesn't exist → create combo_choise and template
            combo_choise = ProductCombo.search([
                ('presta_combo_id', '=', prestashop_product_id)
            ], limit=1)

            if combo_choise:
                combo_choise.write({'name': product_name})
            else:
                combo_choise = ProductCombo.create({
                    'name': product_name,
                    'presta_combo_id': prestashop_product_id,
                })

            vals['combo_ids'] = [(6, 0, [combo_choise.id])]

            try:
                template = ProductTemplate.create(vals)
            except Exception as e:
                _logger.warning(f"⚠️ Combo product creation failed: {vals} → Error: {str(e)}")
                return None
            existing_template = template  # For return below

        # ✅ Add combo items (without unlink)
        for item in product_bundle:
            product_template = ProductTemplate.search([
                ('prestashop_product_id', '=', int(item['id']))
            ], limit=1)

            if not product_template:
                continue

            product = product_template.product_variant_id
            if not product:
                continue


            # Check if this combo already has the item
            existing_item = ProductComboItem.search([
                ('combo_id', '=', combo_choise.id),
                ('product_id', '=', product.id)
            ], limit=1)

            if not existing_item:
                ProductComboItem.create({
                    'combo_id': combo_choise.id,
                    'product_id': product.id,
                })

        return existing_template

    def _create_or_update_product(self, vals, product_data=None):
        try:
            presta_id = vals.get('prestashop_product_id')
            domain = [('prestashop_product_id', '=', presta_id)]
            existing = self.search(domain, limit=1)

            if existing:
                existing.write(vals)
                template = existing
            else:
                template = self.create(vals)

            if product_data:
                self._sync_attribute_lines_from_presta(template, product_data)
                self._assign_categories_from_presta(product_data, template)
                self.env['product.product'].update_stock_available_id(product_data)

            return template
        except Exception as e:
            _logger.error(f"Product sync failed: {str(e)}")
            return None

    @api.model
    def sync_prestashop_product_stock(self, base_url, api_key):
        """
        Sync stock quantities from PrestaShop to Odoo for both standard and combination products.
        """
        base_url = base_url.rstrip('/')
        headers = {'Accept': 'application/json'}

        stock_url = f"{base_url}/stock_availables/?output_format=JSON"
        print(stock_url)
        response = requests.get(stock_url, headers=headers, auth=(api_key, ''))

        if response.status_code != 200:
            _logger.warning("Failed to fetch stock availables: %s", response.text)
            return

        stock_data = response.json().get("stock_availables", [])
        if not stock_data:
            _logger.info("No stock data found in PrestaShop.")
            return

        for item in stock_data:
            stock_id = item.get('id')
            detail_url = f"{base_url}/stock_availables/{stock_id}?output_format=JSON"
            detail_response = requests.get(detail_url, headers=headers, auth=(api_key, ''))
            if detail_response.status_code != 200:
                continue

            detail = detail_response.json().get("stock_available", {})
            product_id = int(detail.get("id_product", 0))
            combination_id = int(detail.get("id_product_attribute", 0))
            quantity = float(detail.get("quantity", 0.0))

            if not product_id:
                continue

            # Fetch product type from main product
            product_url = f"{base_url}/products/{product_id}?output_format=JSON"
            product_response = requests.get(product_url, headers=headers, auth=(api_key, ''))
            if product_response.status_code != 200:
                continue

            product_data = product_response.json().get("product", {})
            product_type = product_data.get("product_type")

            # ✅ Standard Product Stock Sync
            if product_type == "standard" and combination_id == 0:
                template = self.search([
                    ('prestashop_product_id', '=', product_id),
                ], limit=1)

                if not template or not template.is_storable:
                    continue

                product = template.product_variant_id
                if not product:
                    continue

            # ✅ Combination Product Stock Sync
            elif product_type == "combinations" and combination_id != 0:
                product = self.env['product.product'].search([
                    ('prestashop_product_id', '=', product_id),
                    ('prestashop_combination_id', '=', combination_id),
                ], limit=1)

                if not product or not product.product_tmpl_id.is_storable:
                    continue

            else:
                continue  # Not standard or combinations

            # ✅ Update stock using quants
            stock_quant = self.env['stock.quant'].search([
                ('product_id', '=', product.id),
                ('location_id.usage', '=', 'internal')
            ], limit=1)

            warehouse = self.env['stock.warehouse'].search(
                [('company_id', '=', self.env.company.id)], limit=1
            )

            if stock_quant:
                stock_quant.quantity = quantity
            else:
                location = self.env['stock.location'].search([('usage', '=', 'internal')], limit=1)
                if location and warehouse:
                    self.env['stock.quant'].with_context(inventory_mode=True).create({
                        'product_id': product.id,
                        'location_id': warehouse.lot_stock_id.id,
                        'quantity': quantity,
                    })

            _logger.info(f"✅ Stock synced: {product.display_name} → Qty: {quantity}")



