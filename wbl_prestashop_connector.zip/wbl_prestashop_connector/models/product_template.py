import requests
from odoo import models, fields, api


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    prestashop_product_id = fields.Integer(string="PrestaShop Product ID")

    def sync_products_from_prestashop(self, base_url=None, api_key=None):
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        base_url = base_url.rstrip('/') + "/api"
        headers = {'Accept': 'application/json'}

        list_url = f"{base_url}/products/?output_format=JSON"
        response = requests.get(list_url, headers=headers, auth=(api_key, ''))

        if response.status_code != 200:
            raise Exception(f"Failed to fetch product list: {response.text}")

        product_list = response.json().get("products", [])
        for prod in product_list:
            product_id = prod.get("id")
            product_data = self._get_prestashop_product(base_url, api_key, product_id)
            if not product_data:
                continue

            vals = self._prepare_product_vals(product_data)
            self._create_or_update_product(vals, product_data)

    def _get_prestashop_product(self, base_url, api_key, product_id):
        url = f"{base_url}/products/{product_id}/?output_format=JSON"
        response = requests.get(url, headers={'Accept': 'application/json'}, auth=(api_key, ''))
        if response.status_code == 200:
            return response.json().get("product", {})
        return None

    def _prepare_product_vals(self, product):
        name = product.get("name", [{}])[0].get("value", "")
        price = float(product.get("price", 0.0))
        reference = product.get('reference')
        height = float(product.get("height", 0.0)) / 100
        depth = float(product.get("depth", 0.0)) / 100
        width = float(product.get("width", 0.0)) / 100
        weight = product.get("weight")
        volume = float(height * depth * width)
        description = product.get("description", [{}])[0].get("value", "")
        product_type = product.get("product_type")
        cost_price = product.get('wholesale_price')

        if product_type in ["standard", "combination"]:
            odoo_type = "consu"
        elif product_type == "virtual":
            odoo_type = "service"
        elif product_type == "pack":
            odoo_type = "combo"
        else:
            odoo_type = "consu"

        return {
            'prestashop_product_id': int(product.get("id")),
            'name': name,
            'list_price': price,  # ✅ Correct field name is list_price in product.template
            'default_code': reference,
            'weight': weight,
            'volume': volume,
            'description': description,
            'type': odoo_type,
            'standard_price': cost_price,
        }

    def _sync_attribute_lines_from_presta(self, template, product_data):
        """
        Sync attribute values from PrestaShop product to Odoo product.template.attribute.line
        """
        option_values = product_data.get('associations', {}).get('product_option_values', [])

        if not option_values:
            return  # attributes nhi ha to.

        presta_val_ids = [int(val['id']) for val in option_values]

        odoo_values = self.env['product.attribute.value'].search([
            ('prestashop_attr_value_id', 'in', presta_val_ids)
        ])

        grouped = {}
        for val in odoo_values:
            attr_id = val.attribute_id.id
            grouped.setdefault(attr_id, []).append(val.id)

        attribute_lines = [(0, 0, {
            'attribute_id': attr_id,
            'value_ids': [(6, 0, val_ids)],
        }) for attr_id, val_ids in grouped.items()]

        if attribute_lines:
            template.write({
                'attribute_line_ids': [(5, 0, 0)] + attribute_lines
            })

    def _create_or_update_product(self, vals, product_data=None):
        domain = [('prestashop_product_id', '=', vals.get('prestashop_product_id'))]
        existing = self.search(domain, limit=1)
        if existing:
            existing.write(vals)
            template = existing
        else:
            template = self.create(vals)

        if product_data:
            self._sync_attribute_lines_from_presta(template, product_data)
            self._assign_categories_from_presta(product_data, template)

        return template

    def _assign_categories_from_presta(self, product_data, template):
        category_ids = set()

        # ✅ Default category (must have)
        default_cat = product_data.get("id_category_default")
        if default_cat:
            category_ids.add(int(default_cat))

        # ✅ Other associated categories
        associations = product_data.get("associations", {})
        for cat in associations.get("categories", []):
            category_ids.add(int(cat['id']))

        if not category_ids:
            return

        # ✅ Find matching Odoo categories
        odoo_cats = self.env['product.public.category'].search([
            ('prestashop_category_id', 'in', list(category_ids))
        ])

        # ✅ Assign to many2many field
        if odoo_cats:
            template.public_categ_ids = [(6, 0, odoo_cats.ids)]
