import requests
from odoo import models, fields, api
import logging

_logger = logging.getLogger(__name__)


class StockQuant(models.Model):
    _inherit = 'stock.quant'


    def sync_stock_from_prestashop(self, base_url=None, api_key=None):
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        base_url = base_url.rstrip('/') + "/api"
        headers = {'Accept': 'application/json'}
        print(base_url)

        list_url = f"{base_url}/stock_availables/?output_format=JSON"
        response = requests.get(list_url, headers=headers, auth=(api_key, ''))
        print(list_url)
        if response.status_code != 200:
            raise Exception(f"Failed to fetch product list: {response.text}")

