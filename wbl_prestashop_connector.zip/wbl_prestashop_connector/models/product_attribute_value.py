import requests
from odoo import models, fields, api


class ProductAttributeValue(models.Model):
    _inherit = 'product.attribute.value'

    prestashop_attr_value_id = fields.Integer(string="PrestaShop Value ID", index=True)

    @api.model
    def sync_attribute_values_from_prestashop(self, base_url=None, api_key=None):
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        base_url = base_url.rstrip('/') + "/api"
        headers = {'Accept': 'application/json'}

        list_url = f"{base_url}/product_option_values/?output_format=JSON"
        response = requests.get(list_url, headers=headers, auth=(api_key, ''))

        if response.status_code != 200:
            raise Exception(f"Failed to fetch attribute values list: {response.text}")

        value_list = response.json().get("product_option_values", [])

        for val in value_list:
            val_id = val.get("id")
            val_data = self._get_prestashop_value(base_url, api_key, val_id)
            if not val_data:
                continue

            vals = self._prepare_value_vals(val_data)
            print(vals)
            self._create_or_update_value(vals)

    def _get_prestashop_value(self, base_url, api_key, val_id):
        url = f"{base_url}/product_option_values/{val_id}/?output_format=JSON"
        response = requests.get(url, headers={'Accept': 'application/json'}, auth=(api_key, ''))
        if response.status_code == 200:
            return response.json().get("product_option_value", {})
        return None

    def _prepare_value_vals(self, data):
        name_list = data.get("name", [])

        def _get_lang_value(lst, lang_id='1'):
            for item in lst:
                if item.get("id") == lang_id:
                    return item.get("value")
            return lst[0].get("value") if lst else "Unnamed"

        name = _get_lang_value(name_list)
        prestashop_attribute_id = int(data.get("id_attribute_group"))
        value_id = int(data.get("id"))

        attribute = self.env['product.attribute'].search([('prestashop_attribute_id', '=', prestashop_attribute_id)], limit=1)

        if not attribute:
            raise Exception(f"Attribute with PrestaShop ID {prestashop_attribute_id} not found in Odoo.")

        return {
            'prestashop_attr_value_id': value_id,
            'name': name,
            'attribute_id': attribute.id,
        }

    def _create_or_update_value(self, vals):
        domain = [('prestashop_attr_value_id', '=', vals.get('prestashop_attr_value_id'))]
        existing = self.search(domain, limit=1)
        if existing:
            existing.write(vals)
        else:
            self.create(vals)
