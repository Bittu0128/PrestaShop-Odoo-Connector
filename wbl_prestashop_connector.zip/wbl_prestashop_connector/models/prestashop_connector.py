import requests
from requests.auth import HTTPBasicAuth
from odoo import models, fields, api
from odoo.exceptions import UserError


class PrestashopConnector(models.Model):
    _name = 'prestashop.connector'
    _description = 'Prestashop Connector'

    name = fields.Char(string="Shop Name")
    shop_url = fields.Char(string="Enter Shop URL")
    admin_url = fields.Char(string="Enter Admin Panel URL")
    webservice_key = fields.Char(string="Enter Webservice Key", required=True)

    def get_connection(self):
        return f"{self.shop_url.rstrip('/')}/api"

    def test_connection(self):
        api_url = self.get_connection()
        try:
            response = requests.get(
                f"{api_url}/customers/?output_format=JSON", auth=HTTPBasicAuth(self.webservice_key, '')
            )
            if response.status_code == 200:
                print(response.json())
                return {
                    'effect': {
                        'fadeout': 'message',
                        'message': 'Connection Successful!',
                    }
                }
            else:
                raise UserError(f"API Test Failed: {response.status_code} - {response.text}")
        except Exception as e:
            raise UserError(f"Connection error: {str(e)}")

    # Fetch data (Customer Group's Data)
    def sync_groups_from_prestashop(self):
        for rec in self:
            rec.env['customer.groups'].sync_groups_from_prestashop(
                base_url=rec.shop_url,
                api_key=rec.webservice_key
            )
        return {
            'effect': {
                'fadeout': 'slow',
                'message': 'Customer groups successfully synced from PrestaShop!',
                'type': 'rainbow_man',
            }
        }

    def sync_customers_from_prestashop(self):
        for rec in self:
            rec.env['res.partner'].sync_customers_from_prestashop(
                base_url=rec.shop_url,
                api_key=rec.webservice_key
            )
        return {
            'effect': {
                'fadeout': 'slow',
                'message': 'Customer successfully synced from PrestaShop!',
                'type': 'rainbow_man',
            }
        }