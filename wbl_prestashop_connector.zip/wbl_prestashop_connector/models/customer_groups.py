import requests
from odoo import models, fields, api


class CustomerGroups(models.Model):
    _name = 'customer.groups'
    _description = 'Customer Groups'

    prestashop_group_id = fields.Integer(string='PrestaShop ID', required=True)
    name = fields.Char(string='Group Name',  required=True,)
    reduction = fields.Float(string='Reduction')
    price_display_method = fields.Selection([('0', 'Tax included'), ('1', 'Tax excluded')],
                                            string='Price Display Method')
    show_prices = fields.Boolean(string='Show Prices')
    date_add = fields.Datetime(string='Created On')
    date_upd = fields.Datetime(string='Updated On')

    @api.model
    def sync_groups_from_prestashop(self, base_url=None, api_key=None):
        # Check if API & URL not Found.
        if not base_url or not api_key:
            raise Exception("Missing base URL or API key")

        base_url = base_url.rstrip('/') + "/api"
        headers = {'Accept': 'application/json'}

        # Step 1: Get all group IDs
        list_url = f"{base_url}/groups/?output_format=JSON"  # Create API
        response = requests.get(list_url, headers=headers, auth=(api_key, ''))
        # Check Response
        if response.status_code != 200:
            raise Exception(f"Failed to fetch group list: {response.text}")

        group_ids = response.json().get('groups', [])
        # Iterate loop on groups Values(group)
        for group in group_ids:
            group_id = group.get('id')
            detail_url = f"{base_url}/groups/{group_id}/?output_format=JSON"
            detail_response = requests.get(detail_url, headers=headers, auth=(api_key, ''))

            if detail_response.status_code != 200:
                continue

            group_data = detail_response.json().get('group', {})

            # Get group name
            name_list = group_data.get('name', [])
            group_name = next((item.get('value') for item in name_list if item.get('id') == '1'),
                              name_list[0].get('value') if name_list else '')

            # Process values (Get Value from API).
            reduction = float(group_data.get('reduction'))
            price_display_method = group_data.get('price_display_method', '0')
            show_prices = group_data.get('show_prices')
            date_add = group_data.get('date_add')
            date_upd = group_data.get('date_upd')

            # Create or update the record
            existing = self.search([('prestashop_group_id', '=', int(group_id))], limit=1)
            # If Value alreday present.
            if existing:
                existing.write({
                    'name': group_name,
                    'reduction': reduction,
                    'price_display_method': price_display_method,
                    'show_prices': show_prices,
                    'date_add': date_add,
                    'date_upd': date_upd,
                })
            # If Value not found, so create new record.
            else:
                self.create({
                    'prestashop_group_id': int(group_id),
                    'name': group_name,
                    'reduction': reduction,
                    'price_display_method': price_display_method,
                    'show_prices': show_prices,
                    'date_add': date_add,
                    'date_upd': date_upd,
                })
