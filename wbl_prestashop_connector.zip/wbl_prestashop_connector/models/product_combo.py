from odoo import api, models, fields


class ProductCombo(models.Model):
    _inherit = 'product.combo'

    presta_combo_id = fields.Integer(string="PrestaShop Combo ID")

    item_ids = fields.One2many(
        'product.combo.item',
        'combo_id',
        string='Combo Items'
    )
# purpose hai: product.combo (choise) model se uske linked combo items ko access karna.

