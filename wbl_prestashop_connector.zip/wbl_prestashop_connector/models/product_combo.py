from odoo import api, models


class ProductCombo(models.Model):
    _inherit = 'product.combo'